package com.depletion.ledcraft;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SaveFileActivity extends AppCompatActivity {

    //private AppBarConfiguration appBarConfiguration;
    //private ActivitySaveFileBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.savefilelayout);

        //String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand", "Spain", "France", "Belgium", "Brazil", "Mexico"};
        ListView simpleList;

        String files[] = this.fileList();

        simpleList = (ListView)findViewById(R.id.simpleListView);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, R.id.ListViewTextField, files);
        simpleList.setAdapter(arrayAdapter);

        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String value=arrayAdapter.getItem(position);
                //Toast.makeText(getApplicationContext(),value,Toast.LENGTH_SHORT).show();
                ((EditText)findViewById(R.id.FilenameEditBox)).setText(value);
            }
        });


/*        binding = ActivitySaveFileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_save_file);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

 */
    }

/*    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_save_file);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

 */

    public void SaveButtonOnClick(View view) {

        saveFile(null, true);
    }

    public void saveActCancelButtonOnClick(View view) {

        finish();
    }

    void saveFile (String pFileName, boolean askIfFileExists) {

        String filename;
        if (pFileName==null)
            filename =((EditText)findViewById(R.id.FilenameEditBox)).getText().toString();
        else
            filename=pFileName;

        if (askIfFileExists) {
            if (fileExists(filename)) {
                // ToDo: load text from string resources (v2)
                //Toast.makeText(getApplicationContext(),"FILE EXISTS ",Toast.LENGTH_SHORT).show();
                AlertDialog alertDialog = new AlertDialog.Builder(SaveFileActivity.this).create();
                alertDialog.setTitle("File Exists");
                alertDialog.setMessage("Overwrite file?");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                saveFile(filename, false);
                                //Toast.makeText(getApplicationContext(),"you chose yes ",Toast.LENGTH_SHORT).show();
                            }
                        });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                //Toast.makeText(getApplicationContext(),"you chose no ",Toast.LENGTH_SHORT).show();
                            }
                        });
                alertDialog.show();
                return;
            }
        }


/*        int width=1000, height=1000;

        byte[] fileContents;
        fileContents= new byte[9];
        fileContents[0]='L'; fileContents[1]='C'; fileContents[2]='D'; fileContents[3]='F';// magic
        fileContents[4]=1; // version
        fileContents[5]=(byte)((width&0xff00)>>8);
        fileContents[6]=(byte)(width&0xff);
        fileContents[7]=(byte)((height&0xff00)>>8);
        fileContents[8]=(byte)(height&0xff);
*/
        //get a byte array with the file information
        byte[] fileContents=InformationExchanger.transformLedMovieToLCDFFile(InformationExchanger.saveInfoWidthInLeds,
                InformationExchanger.saveInfoHeightInLeds, InformationExchanger.saveInfoLedMovie);

/*        int rw=fileContents[5]; rw<<=8; rw|=(fileContents[6]&0xff);
        Toast.makeText(getApplicationContext(),"rw="+rw,Toast.LENGTH_SHORT).show();*/

        //Mode private makes file visible only to app
        try (FileOutputStream fos = this.openFileOutput(filename, this.MODE_PRIVATE)) {
            fos.write(fileContents);
            //Toast.makeText(getApplicationContext(),"Written "+fileContents.length+ "bytes",Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            Toast.makeText(getApplicationContext(),"ERROR FileNotFoundException ",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),"ERROR IOException ",Toast.LENGTH_SHORT).show();
        }

        finish(); // end activity after we write the file
    }

    boolean fileExists(String filename) {
        File file = new File(getApplicationContext().getFilesDir(), filename);
        if(file.exists())
            return true;
        else
            return false;
    }

}