package com.depletion.ledcraft;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;


public class FullscreenActivity extends AppCompatActivity {

    boolean upperMenuVisible=true;
    Object activitySyncer;
    int lowerButtonHeight=-1;
    int upperMenuHeight=-1;
    int totalScreenHeight=-1;
    int totalScreenWidth=-1;
    private final float ledsPerInch=5; // leds per inch of physical width/height
    LedMovie ledMovie;
    LedsDrawer ledsDrawer;
    LedPalette ledPalette;
    int ledPanelXStart, ledPanelYStart, ledPanelXEnd, ledPanelYEnd, ledPanelHPixelsPerLed, ledPanelVPixelsPerLed;
    int ledPanelWidthInLeds, ledPanelHeightInLeds;
    int oldColor, oldX=-1, oldY=-1, initialX=-1, initialY=-1;
    boolean gotOutOfInitialLed=false;
    LedPanel clipboard=null;
    Timer playTimer=null;
    boolean isPlaying=false;
    boolean lowerButtonVisible=true;


    private void hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
/*
        // Delayed removal of status and navigation bar
        if (Build.VERSION.SDK_INT >= 30) {
            mContentView.getWindowInsetsController().hide(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
*/

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        // fixed inmersive
                        |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //binding = ActivityFullscreenBinding.inflate(getLayoutInflater());
        //setContentView(binding.getRoot());
        setContentView(R.layout.mainlayout);
        //setContentView(R.layout.testone);

        hideSystemUI();

        //create a palette with the bitmaps
        Bitmap bm0=BitmapFactory.decodeResource(getResources(), R.drawable.led0v2);
        Bitmap bm1=BitmapFactory.decodeResource(getResources(), R.drawable.led1v2);
        Bitmap bm2=BitmapFactory.decodeResource(getResources(), R.drawable.led2v2);
        Bitmap bm3=BitmapFactory.decodeResource(getResources(), R.drawable.led3v2);
        Bitmap bm4=BitmapFactory.decodeResource(getResources(), R.drawable.led4v2);
        Bitmap bm5=BitmapFactory.decodeResource(getResources(), R.drawable.led5v2);
        Bitmap bm6=BitmapFactory.decodeResource(getResources(), R.drawable.led6v2);
        this.ledPalette=new LedPalette(bm0, bm1, bm2, bm3, bm4, bm5, bm6);
        this.ledsDrawer=new LedsDrawer(this, this.ledPalette);
        //
        ((ViewGroup)findViewById(R.id.CanvasLayout)).addView(this.ledsDrawer);

        // color1 is the default color
        ((View)findViewById(R.id.SelectColor1Button)).setBackgroundColor(0xffffff00);


        /*
        ((ViewGroup)findViewById(R.id.CanvasLayout)).addView(myEjemploView);
        //setContentView(new EjemploView(this));
        //((ViewGroup)findViewById(R.id.UpperMenuLayout)).setVisibility(View.VISIBLE);

        ((View)findViewById(R.id.SelectColor1Button)).setBackgroundColor(0xffffff00);
*/

        // MAIN MENU onclick event
        Button button = (Button) findViewById(R.id.MainMenuButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                if (upperMenuVisible) {
                    upperMenuVisible=false;
                    //((ViewGroup)findViewById(R.id.UpperMenuLayout)).setVisibility(View.INVISIBLE);
                    hideUpperMenu();
                } else {
                    upperMenuVisible=true;
                    //((ViewGroup)findViewById(R.id.UpperMenuLayout)).setVisibility(View.VISIBLE);
                    showUpperMenu();
                }

            }
        });

        //test if lower menu button is hideable
        //((ViewGroup)findViewById(R.id.LoweButtonsLayout)).setVisibility(View.INVISIBLE);

        // LEFT button onclick
/*        Button button11 = (Button) findViewById(R.id.LeftButton);
        button11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CharSequence text = "LEFT BUTTON!";
                Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
                Log.d("DEBUG", "TOAST!");
            }
        });*/

        // EXPORT button onclick
/*        Button button111 = (Button) findViewById(R.id.ExportButton);
        button111.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Log.d("DEBUG", "TOAST!");
                Bitmap bitmap111 = BitmapFactory.decodeResource(getResources(), R.drawable.led6);
                MediaStore.Images.Media.insertImage(getContentResolver(), bitmap111, "yourTitle" , "yourDescription");
                Log.d("DEBUG", "Export button");

                // new way to do things
                    //if (Build.VERSION.SdkInt >= BuildVersionCodes.Q)
                    //{
                      //  var contentValues = new ContentValues();
                       // contentValues.Put(MediaStore.MediaColumns.DisplayName, file_name);
                       // contentValues.Put(MediaStore.Files.FileColumns.MimeType, "image/png");
                       // contentValues.Put(MediaStore.MediaColumns.RelativePath, Android.OS.Environment.DirectoryPictures + "relativePath");
                       // contentValues.Put(MediaStore.MediaColumns.IsPending, 1);
                    //}

            }
        });*/

        //ToDo: make all shift buttons with Constraint layout

        this.activitySyncer=new Object();

        ViewGroup upperMenu=((ViewGroup)findViewById(R.id.UpperMenuLayout));
        ViewGroup lowerMenu=((ViewGroup)findViewById(R.id.LoweButtonsLayout));

        upperMenu.post(new Runnable() {
            @Override
            public void run() {
                int i=upperMenu.getHeight(); //height is ready
                //Log.d("DEBUG","upperMenu height="+i);
                synchronized (activitySyncer) {
                    //myEjemploView.setUpperMenuHeight(i);
                    upperMenuHeight=i;
                    checkIfWeHaveAllScreenDimsAndCanCreateMovie();
                }
            }
        });
        lowerMenu.post(new Runnable() {
            @Override
            public void run() {
                int i=lowerMenu.getHeight(); //height is ready
                //Log.d("DEBUG","lowerMenu height="+i);
                synchronized (activitySyncer) {
                    //myEjemploView.setLowerMenuHeight(i);
                    lowerButtonHeight=i;
                    checkIfWeHaveAllScreenDimsAndCanCreateMovie();
                }
            }
        });


        ViewGroup canvasLayout=((ViewGroup)findViewById(R.id.CanvasLayout));
        canvasLayout.post(new Runnable() {
            @Override
            public void run() {
                int h=canvasLayout.getHeight(); //height is ready
                int w=canvasLayout.getWidth(); //height is ready
                //Log.d("DEBUG","canvasLayout height="+h+ " width="+w);
                synchronized (activitySyncer) {
                    //myEjemploView.setTotalHeight(h);
                    //myEjemploView.setTotalWidth(w);
                    totalScreenHeight=h;
                    totalScreenWidth=w;
                    checkIfWeHaveAllScreenDimsAndCanCreateMovie();
                }
            }
        });

        //this function will act as a LedPanel UI Controller
        canvasLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        //Log.d("DEBUG", "MotionEvent.ACTION_DOWN at "+ event.getX(0)+" "+event.getY(0));

                        if (isPlaying)
                            return true;

                        if (upperMenuVisible)
                            return true;
                        //
                        if ((event.getX()>ledPanelXStart)&&(event.getX()<ledPanelXEnd)&&
                                (event.getY()>ledPanelYStart)&&(event.getX()<ledPanelYEnd)) {
                            int ledXCoord=((int)event.getX()-ledPanelXStart)/ledPanelHPixelsPerLed;
                            int ledYCoord=((int)event.getY()-ledPanelYStart)/ledPanelVPixelsPerLed;
                            ledXCoord=Math.min(Math.max(0, ledXCoord), ledPanelWidthInLeds-1);
                            ledYCoord=Math.min(Math.max(0, ledYCoord), ledPanelHeightInLeds-1);
                            /*LedPanel myLedPanel=ledMovie.getCurrentLedPanel();
                            oldColor=myLedPanel.values[ledXCoord][ledYCoord];*/
                            oldColor=getColorFromCurrentLedPanel(ledXCoord, ledYCoord);
                            /*myLedPanel.values[ledXCoord][ledYCoord]=ledPalette.currentColorIndex;*/
                            drawInCurrentLedPanel(ledXCoord, ledYCoord);
                            initialX=oldX=ledXCoord;
                            initialY=oldY=ledYCoord;
                            gotOutOfInitialLed=false;
                            ledsDrawer.invalidate();
                        }
                        else { // initial tap outside ledpanel limits
                            initialX=initialY=-1;
                            oldX=oldY=-2;
                        }


                        return true;
                    case MotionEvent.ACTION_UP:
                        //Log.d("DEBUG", "MotionEvent.ACTION_UP at "+ event.getX(0)+" "+event.getY(0));

                        if (isPlaying) {
                            stopPlaying();
                            return true;
                        }


                        if (upperMenuVisible) {
                            hideUpperMenu();
                            return true;
                        }
                        //
                        if ((event.getX()>ledPanelXStart)&&(event.getX()<ledPanelXEnd)&&
                                (event.getY()>ledPanelYStart)&&(event.getX()<ledPanelYEnd)) {
                            int ledXCoord=((int)event.getX()-ledPanelXStart)/ledPanelHPixelsPerLed;
                            int ledYCoord=((int)event.getY()-ledPanelYStart)/ledPanelVPixelsPerLed;
                            ledXCoord=Math.min(Math.max(0, ledXCoord), ledPanelWidthInLeds-1);
                            ledYCoord=Math.min(Math.max(0, ledYCoord), ledPanelHeightInLeds-1);
                            if ((ledXCoord==initialX)&&(ledYCoord==initialY)&&(ledXCoord==oldX)&&
                                    (ledYCoord==oldY)&&(oldColor==ledPalette.currentColorIndex)&&
                                    (!gotOutOfInitialLed)) {
                                /*LedPanel myLedPanel = ledMovie.getCurrentLedPanel();
                                myLedPanel.values[ledXCoord][ledYCoord] = 0;
                                 */
                                drawInCurrentLedPanel(ledXCoord, ledYCoord, 0);
                                initialX=initialY=oldX=oldY=-1;
                                gotOutOfInitialLed=false;
                                ledsDrawer.invalidate();
                            }
                            //Log.d("DEBUG", "UPTOUCH at "+ ledXCoord + ","+ledYCoord +"with oldX="+oldX+" and oldY="+oldY+" oldColor="+oldColor);
                        }

                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Log.d("DEBUG", "MotionEvent.ACTION_MOVE at "+ event.getX(0)+" "+event.getY(0));

                        if (isPlaying)
                            return true;

                        if (upperMenuVisible)
                            return true;
                        //
                        if ((event.getX()>ledPanelXStart)&&(event.getX()<ledPanelXEnd)&&
                            (event.getY()>ledPanelYStart)&&(event.getX()<ledPanelYEnd)) {
                            int ledXCoord=((int)event.getX()-ledPanelXStart)/ledPanelHPixelsPerLed;
                            int ledYCoord=((int)event.getY()-ledPanelYStart)/ledPanelVPixelsPerLed;
                            ledXCoord=Math.min(Math.max(0, ledXCoord), ledPanelWidthInLeds-1);
                            ledYCoord=Math.min(Math.max(0, ledYCoord), ledPanelHeightInLeds-1);
                            if ((ledXCoord!=oldX)||(ledYCoord!=oldY)) {
                                /*LedPanel myLedPanel = ledMovie.getCurrentLedPanel();
                                myLedPanel.values[ledXCoord][ledYCoord] = ledPalette.currentColorIndex;*/
                                drawInCurrentLedPanel(ledXCoord, ledYCoord);
                                oldX=ledXCoord;
                                oldY=ledYCoord;
                                gotOutOfInitialLed=true;
                                ledsDrawer.invalidate();
                            }
                        }

                        return true;
                    default:
                        return false;
                }
            }

        });

        //((ViewGroup)findViewById(R.id.LoweButtonsLayout)).setVisibility(View.INVISIBLE);

        this.hideUpperMenu();

    }

    void checkIfWeHaveAllScreenDimsAndCanCreateMovie() {
        if( (lowerButtonHeight>0)&&
            (upperMenuHeight>0)&&
            (totalScreenHeight>0)&&
            (totalScreenWidth>0) ) {

            /*Log.d("DEBUG","We have all the dimensions: tw="+
                    totalScreenWidth+" th="+totalScreenHeight+" um="+upperMenuHeight+
                    " lb="+lowerButtonHeight);*/

            // get display width and height in inches
            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(dm);

            int effectiveHeight=totalScreenHeight-lowerButtonHeight;
            float widthInInches=totalScreenWidth/dm.xdpi;
            float heightInInches=effectiveHeight/dm.ydpi;

            int ledPanelWidthInLeds=(int)(widthInInches*this.ledsPerInch);
            int ledPanelHeightInLeds=(int)(heightInInches*this.ledsPerInch);

            float inchesPerLed=1/this.ledsPerInch;
            //preliminar results, we'll correct them later
            int ledPanelWidthInPixels=(int)(ledPanelWidthInLeds*inchesPerLed*dm.xdpi);
            int ledPanelHeightInPixels=(int)(ledPanelHeightInLeds*inchesPerLed*dm.ydpi);

            int hPixelsPerLed=ledPanelWidthInPixels/ledPanelWidthInLeds;
            int vPixelsPerLed=ledPanelHeightInPixels/ledPanelHeightInLeds;

            // small correction
            ledPanelWidthInPixels=ledPanelWidthInLeds*hPixelsPerLed;
            ledPanelHeightInPixels=ledPanelHeightInLeds*vPixelsPerLed;

            int xOriginBigView= ((totalScreenWidth-ledPanelWidthInPixels)/2);
            int yOriginBigView= ((effectiveHeight-ledPanelHeightInPixels)/2);

            /*Log.d("DEBUG","Determined width and height in leds: w="+ledPanelWidthInLeds+
                    " h="+ledPanelHeightInLeds);
            Log.d("DEBUG","ledPanelWidthInPixels="+ledPanelWidthInPixels+
                    " ledPanelHeightInPixels="+ledPanelHeightInPixels);
            Log.d("DEBUG", "hPixelsPerLed="+hPixelsPerLed+ " vPixelsPerLed="+vPixelsPerLed);*/

            //
            // Now, the values for the mini-view

            int miniViewAvailableHeight=effectiveHeight-upperMenuHeight;
            float miniViewToBigViewRatio=(float)miniViewAvailableHeight/(float)effectiveHeight;
            //Log.d("DEBUG", "miniViewToBigViewRatio="+miniViewToBigViewRatio);

            //preliminary values, we'll correct them later
            int miniViewLedPanelWidthInPixels=(int)(ledPanelWidthInPixels*miniViewToBigViewRatio);
            int miniViewLedPanelHeightInPixels=(int)(ledPanelHeightInPixels*miniViewToBigViewRatio);
            //Log.d("DEBUG", "miniViewLedPanelWidthInPixels="+miniViewLedPanelWidthInPixels+ " miniViewLedPanelHeightInPixels="+miniViewLedPanelHeightInPixels);

            int miniViewHorizPixelsPerLed=miniViewLedPanelWidthInPixels/ledPanelWidthInLeds;
            int miniViewVerticalPixelsPerLed=miniViewLedPanelHeightInPixels/ledPanelHeightInLeds;

            //correct preliminary values
            miniViewLedPanelWidthInPixels=miniViewHorizPixelsPerLed*ledPanelWidthInLeds;
            miniViewLedPanelHeightInPixels=miniViewVerticalPixelsPerLed*ledPanelHeightInLeds;

            int miniViewXOrigin=((totalScreenWidth-miniViewLedPanelWidthInPixels)/2);
            int miniViewYOrigin=((miniViewAvailableHeight-miniViewLedPanelHeightInPixels)/2);

            // set global constants that the led controller will need
            this.ledPanelXStart=xOriginBigView;
            this.ledPanelYStart=yOriginBigView;
            this.ledPanelXEnd=xOriginBigView+ledPanelWidthInPixels;
            this.ledPanelYEnd=yOriginBigView+ledPanelHeightInPixels;
            this.ledPanelHPixelsPerLed=hPixelsPerLed;
            this.ledPanelVPixelsPerLed=vPixelsPerLed;
            this.ledPanelWidthInLeds=ledPanelWidthInLeds;
            this.ledPanelHeightInLeds=ledPanelHeightInLeds;


            // try to continue previous movie work if available
            LedMovie prevMovie=loadPreviousMovieIfAvailable();
            if (prevMovie==null) {
                this.ledMovie= new LedMovie(ledPanelWidthInLeds, ledPanelHeightInLeds);
            } else {
                this.ledMovie=prevMovie;
            }

            this.ledsDrawer.setDrawingValues(this.ledMovie, ledPanelWidthInLeds, ledPanelHeightInLeds, xOriginBigView, yOriginBigView, hPixelsPerLed, vPixelsPerLed, miniViewXOrigin, miniViewYOrigin, miniViewHorizPixelsPerLed, miniViewVerticalPixelsPerLed);
            this.ledsDrawer.invalidate();

            // update page counter
            updateCurrentLedPanelLabel();
        }
    }

    // hide the upper menu
    void hideUpperMenu() {
        this.upperMenuVisible=false;
        ((ViewGroup)findViewById(R.id.UpperMenuLayout)).setVisibility(View.INVISIBLE);
        this.ledsDrawer.showMiniView=false;
        this.ledsDrawer.invalidate();
    }

    // show upper menu
    void showUpperMenu() {
        this.upperMenuVisible=true;
        ((ViewGroup)findViewById(R.id.UpperMenuLayout)).setVisibility(View.VISIBLE);
        this.ledsDrawer.showMiniView=true;
        this.ledsDrawer.invalidate();
    }

    void hideMenuButton() {
        this.lowerButtonVisible=false;
        ((ViewGroup)findViewById(R.id.LoweButtonsLayout)).setVisibility(View.INVISIBLE);
        //this.ledsDrawer.showMiniView=false;
        this.ledsDrawer.invalidate();
    }

    // show upper menu
    void showMenuButton() {
        this.lowerButtonVisible=true;
        ((ViewGroup)findViewById(R.id.LoweButtonsLayout)).setVisibility(View.VISIBLE);
        //this.ledsDrawer.showMiniView=true;
        this.ledsDrawer.invalidate();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        /*        delayedHide(100);*/
    }

    @Override
    public void onResume(){
        super.onResume();
        // put your code here...
        //FullScreencall();

    }

    @Override
    public void onPause(){
        super.onPause();
        // put your code here...
        if (isPlaying)
            stopPlaying();
        //Log.d("DEBUG", "onPause");
    }

    public void onStop(){
        super.onStop();
        //Log.d("DEBUG", "onStop");
    }

    protected void onDestroy (){
        super.onDestroy();
        //Log.d("DEBUG", "onDestroy");
        saveCurrentMovieToTempFile();
    }

    protected void onStart (){
        super.onStart();
        hideSystemUI(); // in case we have regained focus
        //Log.d("DEBUG", "onStart");
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus)
            hideSystemUI();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == InformationExchanger.LOAD_ACTIVITY_REQUEST_CODE
                && resultCode == InformationExchanger.LOAD_ACTIVITY_RESULT_CODE_MOVIE_LOADED) {
            //Log.d("DEBUG", "I should load a new movie here");
            this.ledMovie.ledPanels.clear();
            this.ledMovie.ledPanels=InformationExchanger.loadInfoLedMovie.ledPanels;
            this.ledMovie.currentLedPanelNumber=0;
            updateCurrentLedPanelLabel();
            ledsDrawer.invalidate();
        }
    }


    LedMovie loadPreviousMovieIfAvailable(){

        LedMovie tempMovie= null;
        byte[] fileContents;
        int bytesRead=0;

        if (fileExists(InformationExchanger.temporaryFilename))
        {
            fileContents=new byte[InformationExchanger.loadInfoMaxFileSize];

            //Mode private makes file visible only to app
            try (FileInputStream fis = this.openFileInput(InformationExchanger.temporaryFilename)) {
                bytesRead=fis.read(fileContents);

            } catch (FileNotFoundException e) {
                //e.printStackTrace();
                Toast.makeText(getApplicationContext(),"FileNotFoundException",Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                //e.printStackTrace();
                Toast.makeText(getApplicationContext(),"IOException",Toast.LENGTH_SHORT).show();
            }

            deleteThisFile(InformationExchanger.temporaryFilename);

            tempMovie =InformationExchanger.transformLCDFFileToLedMovie(
                    fileContents, bytesRead,
                    this.ledPanelWidthInLeds, this.ledPanelHeightInLeds);

            //Log.d("DEBUG", "Temporary movie recovered");
            return tempMovie;
        } else
            return null;
    }

    void saveCurrentMovieToTempFile(){

        //get a byte array with the file information
        byte[] fileContents=InformationExchanger.transformLedMovieToLCDFFile(this.ledPanelWidthInLeds,
            this.ledPanelHeightInLeds, this.ledMovie);

        //Mode private makes file visible only to app
        try (FileOutputStream fos = this.openFileOutput(InformationExchanger.temporaryFilename,
                this.MODE_PRIVATE)) {
                fos.write(fileContents);
            } catch (FileNotFoundException e) {
                Toast.makeText(getApplicationContext(),"ERROR FileNotFoundException ",Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(getApplicationContext(),"ERROR IOException ",Toast.LENGTH_SHORT).show();
            }

    }



    boolean fileExists(String filename) {
        File file = new File(getApplicationContext().getFilesDir(), filename);
        if(file.exists())
            return true;
        else
            return false;
    }

    void deleteThisFile(String filename) {
        File file = new File(getApplicationContext().getFilesDir(), filename);
        if(file.exists())
            file.delete();
    }


    //
    // Buttons click functions
    //
    public void color0ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=0;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color1ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=1;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color2ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=2;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color3ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=3;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color4ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=4;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color5ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=5;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    public void color6ButtonClick(View view) {
        //Log.d ("DEBUG", "color0 Onlick");
        this.ledPalette.currentColorIndex=6;
        setAllColorSelectionButtonsBGBlack();
        view.setBackgroundColor(0xffffff00);
    }
    private void setAllColorSelectionButtonsBGBlack(){
        ((View)findViewById(R.id.SelectColor0Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor1Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor2Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor3Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor4Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor5Button)).setBackgroundColor(0x00000000);
        ((View)findViewById(R.id.SelectColor6Button)).setBackgroundColor(0x00000000);
    }
    public void SaveButtonClick(View view) {
        //information to pass to the save activity
        InformationExchanger.saveInfoWidthInLeds=this.ledPanelWidthInLeds;
        InformationExchanger.saveInfoHeightInLeds=this.ledPanelHeightInLeds;
        InformationExchanger.saveInfoLedMovie=this.ledMovie;

        //launch activity
        Intent intent = new Intent(this, SaveFileActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editTextTextPersonName);
        //String message = editText.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);

    }
    //ToDo: clear saveInfoLedMovie and loadInfoLedMovie of InformationExchanger to free its memory after they've been used (v2)
    public void LoadButtonClick(View view) {
/*        Intent intent = new Intent(this, LoadFileActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editTextTextPersonName);
        //String message = editText.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
 */
        InformationExchanger.loadInfoWidthInLeds=this.ledPanelWidthInLeds;
        InformationExchanger.loadInfoHeightInLeds=this.ledPanelHeightInLeds;

        Intent intent = new Intent(this, LoadFileActivity.class);
        startActivityForResult(intent,InformationExchanger.LOAD_ACTIVITY_REQUEST_CODE);
    }
    public void moveLeftButtonClick(View view) {
        moveLeft();
    }
    public void moveRightButtonClick(View view) {
        moveRight();
    }
    public void copyButtonClick(View view) {
        copyOperation();
    }
    public void cutButtonClick(View view) {
        cutOperation();
    }
    public void pasteRightButtonClick(View view) {
        pasteOperation();
    }
    public void shiftUpButtonClick(View view) {
        shiftUpOperation();
    }
    public void shiftDownButtonClick(View view) {
        shiftDownOperation();
    }
    public void shiftLeftButtonClick(View view) {
        shiftLeftOperation();
    }
    public void shiftRightButtonClick(View view) {
        shiftRightOperation();
    }
    public void play1FPS (View view) {
        setupPlayAt(1000);
    }
    public void play2FPS (View view) {
        setupPlayAt(500);
    }
    public void play5FPS (View view) {
        setupPlayAt(200);
    }

    public void newButtonClick(View view) {

        //ToDo: load strings of dialog from resources
        AlertDialog alertDialog = new AlertDialog.Builder(FullscreenActivity.this).create();
        alertDialog.setTitle("New Animation");
        alertDialog.setMessage("Discard current file?");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        startNewAnimation();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }


        //
    // leddrawer controller functions
    //
    void startNewAnimation(){
        this.ledMovie.ledPanels.clear();
        this.ledMovie.currentLedPanelNumber=0;
        this.ledMovie.ledPanels.add(new LedPanel(this.ledPanelWidthInLeds, this.ledPanelHeightInLeds));
        this.ledsDrawer.invalidate();
        updateCurrentLedPanelLabel();
    }

    void setupPlayAt(int ms){
        hideUpperMenu();
        hideMenuButton();
        //reset movie to 0
        ledMovie.currentLedPanelNumber=0;
        ledsDrawer.invalidate();
        // setup the timer task
        playTimer=new Timer();

        TimerTask playTask = new TimerTask() {
        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (ledMovie.currentLedPanelNumber>=(ledMovie.ledPanels.size()-1)) {
                        ledMovie.currentLedPanelNumber=0;
                    }
                    else {
                        ledMovie.currentLedPanelNumber++;
                    }
                    ledsDrawer.invalidate(); // show the frame
                    }
                });
            }
        };

        playTimer.schedule(playTask, ms, ms);
        // needed to know we're in the middle of playing
        isPlaying=true;
    }
/*    TimerTask playTask = new TimerTask() {
        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (ledMovie.currentLedPanelNumber>=(ledMovie.ledPanels.size()-1)) {
                        ledMovie.currentLedPanelNumber=0;
                    }
                    else {
                        ledMovie.currentLedPanelNumber++;
                    }
                    ledsDrawer.invalidate(); // show the frame
                }
            });
        }
    };*/
    void stopPlaying() {
        playTimer.cancel();
        playTimer=null;
        isPlaying=false;
        showMenuButton();
    }
    void drawInCurrentLedPanel(int x, int y) {
        LedPanel myLedPanel = ledMovie.getCurrentLedPanel();
        myLedPanel.values[x][y] = ledPalette.currentColorIndex;

    }
    void drawInCurrentLedPanel(int x, int y, int color) {
        LedPanel myLedPanel = ledMovie.getCurrentLedPanel();
        myLedPanel.values[x][y] = color;

    }
    int getColorFromCurrentLedPanel(int x, int y) {
        LedPanel myLedPanel = ledMovie.getCurrentLedPanel();
        return myLedPanel.values[x][y];
    }
    void moveRight(){
        if (ledMovie.currentLedPanelNumber>=(ledMovie.ledPanels.size()-1)) {
            ledMovie.ledPanels.add(new LedPanel(ledPanelWidthInLeds, ledPanelHeightInLeds));
            ledMovie.currentLedPanelNumber=(ledMovie.ledPanels.size()-1);
        }
        else {
            ledMovie.currentLedPanelNumber++;
        }

        ledsDrawer.invalidate();
        updateCurrentLedPanelLabel();
    }
    void moveLeft(){
        if (ledMovie.currentLedPanelNumber<=0) {
            ledMovie.currentLedPanelNumber=0;
        }
        else {
            ledMovie.currentLedPanelNumber--;
        }

        ledsDrawer.invalidate();
        updateCurrentLedPanelLabel();
    }
    void updateCurrentLedPanelLabel() {
        ((TextView)findViewById(R.id.PageCounterText)).setText(""+(ledMovie.currentLedPanelNumber+1)+"/"+ledMovie.ledPanels.size());
    }
    void copyOperation() {
        clipboard=cloneLedPanel(ledMovie.getCurrentLedPanel());
        //updateCurrentLedPanelLabel();
    }
    void cutOperation() {
        clipboard=cloneLedPanel(ledMovie.getCurrentLedPanel());
        ledMovie.ledPanels.remove(ledMovie.currentLedPanelNumber);
        // did we remove the last panel?
        if (ledMovie.currentLedPanelNumber>(ledMovie.ledPanels.size()-1))
            ledMovie.currentLedPanelNumber=(ledMovie.ledPanels.size()-1);
        // did we remove all elements from a Led Movie?
        if (ledMovie.ledPanels.size()<=0) {
            ledMovie.ledPanels.add(new LedPanel(ledPanelWidthInLeds, ledPanelHeightInLeds));
            ledMovie.currentLedPanelNumber=0;
        }
        updateCurrentLedPanelLabel();
        ledsDrawer.invalidate();
    }
    void pasteOperation() {
        if (clipboard==null)
            return;
        LedPanel lp=cloneLedPanel(clipboard);
        ledMovie.ledPanels.add(ledMovie.currentLedPanelNumber, lp);
        updateCurrentLedPanelLabel();
        ledsDrawer.invalidate();
    }
    LedPanel cloneLedPanel (LedPanel ledpanelp) {
        LedPanel clone=new LedPanel(ledpanelp.width, ledpanelp.height);
        for (int y=0; y<clone.height; y++) {
            for (int x = 0; x < clone.width; x++) {
                clone.values[x][y] = ledpanelp.values[x][y];
            }
        }
        return clone;
    }

    void shiftUpOperation() {
/*        let ledsBackup=[];

        for (let i=0; i<this.width; i++)
            ledsBackup.push(this.getLed(i, 0));

        for (let y=1; y<this.height; y++)
            for (let x=0; x<this.width; x++){
                this.setLed(x, y-1, this.getLed(x, y));
            }

        for (let i=0; i<this.width; i++)
            this.setLed(i, this.height-1, ledsBackup[i]);
*/
        int[] ledsBackup= new int[ledPanelWidthInLeds];
        LedPanel myLedPanel=ledMovie.getCurrentLedPanel();

        for (int i=0; i<ledPanelWidthInLeds; i++)
            ledsBackup[i]=myLedPanel.values[i][0];

        for (int y=1; y<ledPanelHeightInLeds; y++)
            for (int x=0; x<ledPanelWidthInLeds; x++){
                myLedPanel.values[x][y-1]=myLedPanel.values[x][y];
            }

        for (int i=0; i<ledPanelWidthInLeds; i++)
            myLedPanel.values[i][ledPanelHeightInLeds-1]=ledsBackup[i];

        ledsDrawer.invalidate();
    }
    void shiftDownOperation() {
/*        let ledsBackup=[];

        for (let i=0; i<this.width; i++)
            ledsBackup.push(this.getLed(i, this.height-1));

        for (let y=this.height-2; y>=0; y--)
            for (let x=0; x<this.width; x++){
                this.setLed(x, y+1, this.getLed(x, y));
            }

        for (let i=0; i<this.width; i++)
            this.setLed(i, 0, ledsBackup[i]);
*/
        int[] ledsBackup= new int[ledPanelWidthInLeds];
        LedPanel myLedPanel=ledMovie.getCurrentLedPanel();

        for (int i=0; i<ledPanelWidthInLeds; i++)
            ledsBackup[i]=myLedPanel.values[i][ledPanelHeightInLeds-1];

        for (int y=ledPanelHeightInLeds-2; y>=0; y--)
            for (int x=0; x<ledPanelWidthInLeds; x++){
                myLedPanel.values[x][y+1]=myLedPanel.values[x][y];
            }

        for (int i=0; i<ledPanelWidthInLeds; i++)
            myLedPanel.values[i][0]=ledsBackup[i];

        ledsDrawer.invalidate();
    }
    void shiftLeftOperation() {
/*        let ledsBackup=[];

        for (let i=0; i<this.height; i++)
            ledsBackup.push(this.getLed(0, i));

        for (let y=0; y<this.height; y++)
            for (let x=1; x<this.width; x++){
                this.setLed(x-1, y, this.getLed(x, y));
            }

        for (let i=0; i<this.height; i++)
            this.setLed(this.width-1, i, ledsBackup[i]);

 */
        int[] ledsBackup= new int[ledPanelHeightInLeds];
        LedPanel myLedPanel=ledMovie.getCurrentLedPanel();

        for (int i=0; i<ledPanelHeightInLeds; i++)
            ledsBackup[i]=myLedPanel.values[0][i];

        for (int y=0; y<ledPanelHeightInLeds; y++)
            for (int x=1; x<ledPanelWidthInLeds; x++){
                myLedPanel.values[x-1][y]=myLedPanel.values[x][y];
            }

        for (int i=0; i<ledPanelHeightInLeds; i++)
            myLedPanel.values[ledPanelWidthInLeds-1][i]=ledsBackup[i];

        ledsDrawer.invalidate();
    }
    void shiftRightOperation() {
/*        let ledsBackup=[];

        for (let i=0; i<this.height; i++)
            ledsBackup.push(this.getLed(this.width-1, i));

        for (let y=0; y<this.height; y++)
            for (let x=this.width-2; x>=0; x--){
                this.setLed(x+1, y, this.getLed(x, y));
            }

        for (let i=0; i<this.height; i++)
            this.setLed(0, i, ledsBackup[i]);

 */
        int[] ledsBackup= new int[ledPanelHeightInLeds];
        LedPanel myLedPanel=ledMovie.getCurrentLedPanel();

        for (int i=0; i<ledPanelHeightInLeds; i++)
            ledsBackup[i]=myLedPanel.values[ledPanelWidthInLeds-1][i];

        for (int y=0; y<ledPanelHeightInLeds; y++)
            for (int x=ledPanelWidthInLeds-2; x>=0; x--){
                myLedPanel.values[x+1][y]=myLedPanel.values[x][y];
            }

        for (int i=0; i<ledPanelHeightInLeds; i++)
            myLedPanel.values[0][i]=ledsBackup[i];

        ledsDrawer.invalidate();
    }
}