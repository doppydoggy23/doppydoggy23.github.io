package com.depletion.ledcraft;

import java.util.ArrayList;

public class LedMovie {

    int ledPanelWidth, ledPanelHeight;
    ArrayList<LedPanel> ledPanels;
    int currentLedPanelNumber;

    public LedMovie(int w, int h) {

        this.ledPanelWidth=w; this.ledPanelHeight=h;
        this.ledPanels= new ArrayList<LedPanel>(); // Create an ArrayList object
        this.ledPanels.add(new LedPanel(w, h));
        this.currentLedPanelNumber=0;
    }

    public LedPanel getCurrentLedPanel() {
        return this.ledPanels.get(this.currentLedPanelNumber);
    }
}
