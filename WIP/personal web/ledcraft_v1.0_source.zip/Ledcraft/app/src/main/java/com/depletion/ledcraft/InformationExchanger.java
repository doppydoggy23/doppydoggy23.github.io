package com.depletion.ledcraft;

public class InformationExchanger {
    static public int saveInfoWidthInLeds=-1;
    static public int saveInfoHeightInLeds=-1;
    static public LedMovie saveInfoLedMovie=null;

    static public int loadInfoWidthInLeds=-1;
    static public int loadInfoHeightInLeds=-1;
    static public int loadInfoMaxFileSize=20*1024*1024;
    static public LedMovie loadInfoLedMovie=null;


    static public int LOAD_ACTIVITY_REQUEST_CODE=123;
    static public int LOAD_ACTIVITY_RESULT_CODE_MOVIE_LOADED=124;
    static public int LOAD_ACTIVITY_RESULT_CODE_NOTHING_LOADED=125;

    static public String temporaryFilename="3247938783409560984";

    static public byte[] transformLedMovieToLCDFFile(int widthp, int heightp, LedMovie ledMoviep){
        byte[] fileBuffer;

        fileBuffer=new byte[(ledMoviep.ledPanels.size()*widthp*heightp)+9];
        int fileBufferIndex=0;

        // set header bytes
        fileBuffer[0]='L'; fileBuffer[1]='C'; fileBuffer[2]='D'; fileBuffer[3]='F';// magic
        fileBuffer[4]=1; // version
        fileBuffer[5]=(byte)((widthp&0xff00)>>8);
        fileBuffer[6]=(byte)(widthp&0xff);
        fileBuffer[7]=(byte)((heightp&0xff00)>>8);
        fileBuffer[8]=(byte)(heightp&0xff);

        fileBufferIndex=9;

        //transform led values into bytes array
        for (int ledPanelIndex=0; ledPanelIndex<ledMoviep.ledPanels.size(); ledPanelIndex++) {

            LedPanel lp=ledMoviep.ledPanels.get(ledPanelIndex);

            for (int y = 0; y < heightp; y++)
                for (int x = 0; x < widthp; x++) {
                    fileBuffer[fileBufferIndex] =(byte)lp.values[x][y];
                    fileBufferIndex++;
                }
        }

        return fileBuffer;
    }

    static public LedMovie transformLCDFFileToLedMovie(byte[] byteArray, int byteArraySize,
                                                       int ledMovieWidth, int ledMovieHeight){
        LedMovie lmovie;

        lmovie=new LedMovie(ledMovieWidth, ledMovieHeight);
        lmovie.ledPanels.clear();

        int fileBufferIndex=9; // skip file header

        while (fileBufferIndex<byteArraySize) {
            LedPanel myLedPanel= new LedPanel(ledMovieWidth, ledMovieHeight);
            for (int y=0; y<ledMovieHeight; y++)
                for (int x=0; x<ledMovieWidth; x++) {
                    myLedPanel.values[x][y]=byteArray[fileBufferIndex];
                    fileBufferIndex++;
                }
            lmovie.ledPanels.add(myLedPanel);
        }

        return lmovie;
    }
}
