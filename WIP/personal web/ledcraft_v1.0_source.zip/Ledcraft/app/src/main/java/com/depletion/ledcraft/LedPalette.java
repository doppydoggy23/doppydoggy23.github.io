package com.depletion.ledcraft;

import android.graphics.Bitmap;

public class LedPalette {
    public int currentColorIndex=1;
    Bitmap colors[];

    LedPalette (Bitmap l0, Bitmap l1, Bitmap l2, Bitmap l3, Bitmap l4, Bitmap l5, Bitmap l6){
        this.colors=new Bitmap[7];
        this.currentColorIndex=1;
        colors[0]=l0;
        colors[1]=l1;
        colors[2]=l2;
        colors[3]=l3;
        colors[4]=l4;
        colors[5]=l5;
        colors[6]=l6;
    }
}
