package com.depletion.ledcraft;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LoadFileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loadfilelayout);

        ListView filesToLoadList;

        String files[] = this.fileList();

        filesToLoadList = (ListView)findViewById(R.id.FilesToLoadList);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, R.id.ListViewTextField, files);
        filesToLoadList.setAdapter(arrayAdapter);

        filesToLoadList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // ToDo: load text from string resources (v2)
                String value=arrayAdapter.getItem(position);
                //Toast.makeText(getApplicationContext(),value,Toast.LENGTH_SHORT).show();

                AlertDialog alertDialog = new AlertDialog.Builder(LoadFileActivity.this).create();
                alertDialog.setTitle("Load File");
                alertDialog.setMessage("Load selected file?");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                loadFile(value);
                            }
                        });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();

            }
        });
    }

    void loadFile(String filename){
        int width=-1, height=-1;

        byte[] fileContents=new byte[InformationExchanger.loadInfoMaxFileSize];

        //Mode private makes file visible only to app
        try (FileInputStream fis = this.openFileInput(filename)) {
            int bytesRead=fis.read(fileContents);

            /*
        fileContents[0]='L'; fileContents[1]='C'; fileContents[2]='D'; fileContents[3]='F';// magic
        fileContents[4]=1; // version
        fileContents[5]=(byte)((width&0xff00)>>8);
        fileContents[6]=(byte)(width&0xff);
        fileContents[7]=(byte)((height&0xff00)>>8);
        fileContents[8]=(byte)(height&0xff);
             */
            /*int w=((fileContents[5]&0xff)<<8)+(fileContents[6]&0xff);
            int h=((fileContents[7]&0xff)<<8)+(fileContents[8]&0xff);
            String header=""+(char)fileContents[0]+(char)fileContents[1]+(char)fileContents[2]+(char)fileContents[3];
            Toast.makeText(getApplicationContext(),"Bytes read="+bytesRead+" w="+w+" h="+h+" HDR="+header,Toast.LENGTH_SHORT).show();

             */

            InformationExchanger.loadInfoLedMovie=InformationExchanger.transformLCDFFileToLedMovie(
                    fileContents, bytesRead,
                    InformationExchanger.loadInfoWidthInLeds, InformationExchanger.loadInfoHeightInLeds);
            //
            //
            Intent resultIntent = new Intent();
            //resultIntent.putExtra("some_key", "String data");
            setResult(InformationExchanger.LOAD_ACTIVITY_RESULT_CODE_MOVIE_LOADED, resultIntent);
            finish();

        } catch (FileNotFoundException e) {
            //e.printStackTrace();
            Toast.makeText(getApplicationContext(),"FileNotFoundException",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            //e.printStackTrace();
            Toast.makeText(getApplicationContext(),"IOException",Toast.LENGTH_SHORT).show();
        }
    }

    public void loadMovieActivityCancelButtonClick(View view) {
        Intent resultIntent = new Intent();
        setResult(InformationExchanger.LOAD_ACTIVITY_RESULT_CODE_NOTHING_LOADED, resultIntent);
        finish();
    }


}