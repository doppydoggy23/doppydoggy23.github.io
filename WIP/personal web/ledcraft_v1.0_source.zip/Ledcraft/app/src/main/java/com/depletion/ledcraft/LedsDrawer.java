package com.depletion.ledcraft;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

public class LedsDrawer extends View {
    //private Bitmap myBitmap;
    LedMovie movieToBeDrawn=null;
    int xOrigin, yOrigin, ledWidthInPixels, ledHeightInPixels, ledPanelWidthInLeds, ledPanelHeightInLeds;
    Rect srcRect, dstRect;
    int miniViewXOrigin, miniViewYOrigin, miniViewHorizontalPixelsPerLed, miniViewVerticalPixelsPerLed;
    public boolean showMiniView=false;
    LedPalette myLedPalette;



    public LedsDrawer(Context context, LedPalette lp){
        super(context);
        this.myLedPalette=lp;

        //preallocate objects used in drawing calls
        srcRect=new Rect(0 ,0, 0, 0);
        dstRect=new Rect(0 ,0, 0, 0);

    }

    public void setDrawingValues(LedMovie ledMoviep, int ledPanelWInLeds, int ledPanelHInLeds, int xOriginp, int yOriginp, int ledWidthInPixelsp, int ledHeightInPixelsp, int miniViewXOriginp, int miniViewYOriginp, int miniViewHorizontalPixelsPerLedp, int miniViewVerticalPixelsPerLedp) {
        this.movieToBeDrawn = ledMoviep;
        this.xOrigin = xOriginp;
        this.yOrigin = yOriginp;
        this.ledWidthInPixels = ledWidthInPixelsp;
        this.ledHeightInPixels = ledHeightInPixelsp;
        this.ledPanelWidthInLeds = ledPanelWInLeds;
        this.ledPanelHeightInLeds = ledPanelHInLeds;
        this.miniViewXOrigin = miniViewXOriginp;
        this.miniViewYOrigin = miniViewYOriginp;
        this.miniViewHorizontalPixelsPerLed = miniViewHorizontalPixelsPerLedp;
        this.miniViewVerticalPixelsPerLed = miniViewVerticalPixelsPerLedp;
    }


    protected void onDraw(Canvas canvas){

        if (this.movieToBeDrawn==null)
            return;

        canvas.drawRGB(0, 0, 0);

        if (this.showMiniView) {
            // we assume all led imgs have the same size
            srcRect.set(0, 0, this.myLedPalette.colors[0].getHeight(), this.myLedPalette.colors[0].getHeight());

            for (int y = 0; y < this.ledPanelHeightInLeds; y++)
                for (int x = 0; x < this.ledPanelWidthInLeds; x++) {
                    dstRect.set((this.miniViewXOrigin + (x * this.miniViewHorizontalPixelsPerLed)),
                            (this.miniViewYOrigin + (y * this.miniViewVerticalPixelsPerLed)),
                            (this.miniViewXOrigin + (x * this.miniViewHorizontalPixelsPerLed)) + this.miniViewHorizontalPixelsPerLed,
                            (this.miniViewYOrigin + (y * this.miniViewVerticalPixelsPerLed)) + this.miniViewVerticalPixelsPerLed);
                    int colorIndex=movieToBeDrawn.getCurrentLedPanel().values[x][y];
                    canvas.drawBitmap(this.myLedPalette.colors[colorIndex], srcRect, dstRect, null);
                }
        }
        else { // show big view
            // we assume all led imgs have the same size
            srcRect.set(0, 0, this.myLedPalette.colors[0].getHeight(), this.myLedPalette.colors[0].getHeight());

            for (int y = 0; y < this.ledPanelHeightInLeds; y++)
                for (int x = 0; x < this.ledPanelWidthInLeds; x++) {
                    dstRect.set((this.xOrigin + (x * this.ledWidthInPixels)),
                            (this.yOrigin + (y * this.ledHeightInPixels)),
                            (this.xOrigin + (x * this.ledWidthInPixels)) + this.ledWidthInPixels,
                            (this.yOrigin + (y * this.ledHeightInPixels)) + this.ledHeightInPixels);
                    int colorIndex=movieToBeDrawn.getCurrentLedPanel().values[x][y];
                    canvas.drawBitmap(this.myLedPalette.colors[colorIndex], srcRect, dstRect, null);
                }
        }

    }

}
