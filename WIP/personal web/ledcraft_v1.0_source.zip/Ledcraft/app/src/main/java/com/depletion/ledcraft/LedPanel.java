package com.depletion.ledcraft;

public class LedPanel {

    public int[][] values;
    public int width, height;

    public LedPanel(int w, int h){

        values= new int[w][h];
        this.width=w; this.height=h;

        for (int y=0;y<h; y++){
            for (int x=0; x<w; x++){
                values[x][y]=0;
            }
        }
    }

}
